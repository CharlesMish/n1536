# SAME series — expanded edition

Ten studies, numbered 01–10. Open `same/index.html` for the index or `same/plates.html` for the book.

New studies:

- `same/same-average.html`: 400 fixed records and two fixed pooled rates, with three different group assignments.
- `same/same-law.html`: three nearby initial states under one exact, reversible update rule. Use Play, Restart, the time slider, and the starting-separation controls.

Every exhibit is a standalone HTML file with embedded styles, scripts, and assets. The new studies support UV and Paper presentation. Read the study opens construction and interpretation notes; in Average, Follow the same 400 records exposes the individual records and the count table.

If your browser restricts local-file workers, serve this folder over HTTP. With Python installed, run `python3 -m http.server 8000` from this folder, then open `http://localhost:8000/same/index.html`. Volume forms its designs when opened; allow it to finish.

The index and book use 1–9 to open the corresponding study; 0 opens study 10. Native Tab/Enter navigation also works. In the book, j/k walk the reading sequence.

`EDITORIAL_NOTES.md` explains the additions, retained studies, framing changes, and validation scope. `PREVIOUS_REPAIR_NOTES.md` records the earlier repair pass and is historical.

With Node.js installed, run `node tools/verify.cjs` from any working directory to repeat 38 targeted source, mathematical, catalog, and interface-event checks. No npm dependencies are required. The interface checks use a small DOM event harness, not a browser layout engine.
